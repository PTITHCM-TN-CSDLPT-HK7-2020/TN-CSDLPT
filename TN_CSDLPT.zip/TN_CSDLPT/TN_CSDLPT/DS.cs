﻿namespace TN_CSDLPT
{


    partial class DS
    {
        partial class SP_THONGTINDANGNHAPDataTable
        {
        }
    }
}
